import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-mod',
  templateUrl: './login-mod.component.html',
  styleUrls: ['./login-mod.component.scss']
})
export class LoginModComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
