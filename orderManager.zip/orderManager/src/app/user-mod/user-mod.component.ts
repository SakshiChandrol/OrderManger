import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-mod',
  templateUrl: './user-mod.component.html',
  styleUrls: ['./user-mod.component.scss']
})
export class UserModComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
