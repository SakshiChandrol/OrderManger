import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-mod',
  templateUrl: './order-mod.component.html',
  styleUrls: ['./order-mod.component.scss']
})
export class OrderModComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
